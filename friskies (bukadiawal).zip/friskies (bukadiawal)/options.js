//cards initial row and column amounts
var colInitAmount = 4;
var rowInitAmount = 3;

//amount of images to be randomized, min = half of the card amount, max = 11
var imageStock = 11;

//time out for the start game showing all cards' front side
var startGameCardOpenTimeout = 1000;

//time counter
var counterInitVal = 60;

//time counter speed in milisecond
var interval = 1000;
